/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tarea1JaviaryRamos;

/**
 *
 * @author Javiary
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        int num1,num2,num3,averege;
        
        num1 = 125;
        num2 = 28;
        num3 = -25;
        
        averege = (num1 + num2 + num3)/3;
        
        System.out.println(" El numero 1 es: " + num1);
        System.out.println(" El numero 2 es: " + num2);
        System.out.println(" El numero 3 es: " + num3);
        System.out.println(" El promedio de los numeros es: " + averege);
        
                
    }
}
