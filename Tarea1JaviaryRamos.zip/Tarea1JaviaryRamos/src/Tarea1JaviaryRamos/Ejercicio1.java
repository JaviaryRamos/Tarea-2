/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Tarea1JaviaryRamos;

/**
 *
 * @author Javiary
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("******************************************");
        System.out.println("* Tarea #1                               *");
        System.out.println("* Programacion II                        *");
        System.out.println("* Autor: Javiary Ramos                   *");
        System.out.println("* Fecha de entrega 22 de Jinio del 2022  *");
        System.out.println("******************************************");
        
    }
    
}
